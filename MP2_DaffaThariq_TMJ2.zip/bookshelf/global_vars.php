<?php
$category = [
    "umum" => "Umum",
    "novel" => "Novel",
    "komputer" => "Komputer"
];

$images_dir = "images/";
$pdf_dir = "ebook/";